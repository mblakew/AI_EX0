//! \file Game.hfundamentals::Game</code> class.
//! \author Jeremiah Blanchard
#pragma once
#include "Agent.h"

using namespace std;

namespace ufl_cap4053 { namespace fundamentals {

	class Game
	{
	public:
		static void main();
	};

}}  // namespace ufl_cap4053::fundamentals
